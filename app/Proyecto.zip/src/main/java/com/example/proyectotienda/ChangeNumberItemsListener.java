package com.example.proyectotienda;

public interface ChangeNumberItemsListener {
    void changed();
}
